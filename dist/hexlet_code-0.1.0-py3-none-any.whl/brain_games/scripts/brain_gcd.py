"""Test user's GCD search skills."""
from brain_games.games import brain_gcd


def main():
    """Name as main."""
    brain_gcd.victory_conditions()


if __name__ == '__main__':
    main()
