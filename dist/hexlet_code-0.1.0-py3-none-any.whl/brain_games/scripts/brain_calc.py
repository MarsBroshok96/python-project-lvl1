"""Test user's skill of calculation."""
from brain_games.games import brain_calc


def main():
    """Name as main."""
    brain_calc.victory_conditions()


if __name__ == '__main__':
    main()
