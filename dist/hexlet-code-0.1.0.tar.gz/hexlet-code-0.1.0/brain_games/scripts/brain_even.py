"""Test user's knowledge about numbers parity."""
from brain_games import parity_game_module


def main():
    """Name as main."""
    parity_game_module.is_even()


if __name__ == '__main__':
    main()
