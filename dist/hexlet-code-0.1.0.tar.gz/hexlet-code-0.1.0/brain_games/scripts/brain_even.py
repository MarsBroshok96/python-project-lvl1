"""Test user's knowledge about numbers parity."""
from brain_games.games import brain_even


def main():
    """Name as main."""
    brain_even.victory_conditions()


if __name__ == '__main__':
    main()
