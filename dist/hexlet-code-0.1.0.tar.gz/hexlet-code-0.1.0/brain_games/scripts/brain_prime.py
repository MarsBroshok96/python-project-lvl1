"""Test user's knowledge about prime numbers."""
from brain_games.games import brain_prime


def main():
    """Name as main."""
    brain_prime.victory_conditions()


if __name__ == '__main__':
    main()
